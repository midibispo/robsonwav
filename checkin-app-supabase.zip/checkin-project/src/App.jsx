import React, { useState, useEffect, useCallback } from "react";
import { Check, Lock, Download, Search, X, Users, ArrowLeft, Loader2, Eye, EyeOff, LogOut } from "lucide-react";
import { supabase } from "./lib/supabaseClient";

function formatWhats(v) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 2) return d;
  if (d.length <= 7) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}
function validWhats(v) {
  return v.replace(/\D/g, "").length >= 10;
}
function maskWhats(v) {
  const d = v.replace(/\D/g, "");
  if (d.length < 10) return v;
  const ddd = d.slice(0, 2);
  const rest = d.slice(2);
  const last4 = rest.slice(-4);
  const firstDigit = rest.slice(0, 1);
  return `(${ddd}) ${firstDigit}${"*".repeat(Math.max(rest.length - 5, 0))}-${last4}`;
}
function fmtDateTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export default function App() {
  const [view, setView] = useState("checkin"); // checkin | adminLogin | admin
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) { setSession(data.session); }
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      if (!sess && view === "admin") setView("checkin");
    });
    return () => sub.subscription.unsubscribe();
  }, [view]);

  return (
    <div style={{ minHeight: "100vh", background: "#0B0B14", fontFamily: "ui-sans-serif, system-ui, -apple-system, sans-serif", color: "#F2F1F7", position: "relative", overflow: "hidden" }}>
      <style>{`
        .disp { font-family: ui-sans-serif, system-ui, -apple-system, sans-serif; letter-spacing: -0.02em; }
        @keyframes stampIn { 0% { transform: scale(2.2) rotate(-18deg); opacity: 0; } 55% { transform: scale(0.92) rotate(4deg); opacity: 1; } 75% { transform: scale(1.04) rotate(-2deg); } 100% { transform: scale(1) rotate(-6deg); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes glow { 0%,100% { opacity: .5; } 50% { opacity: 1; } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .stamp { animation: stampIn 0.55s cubic-bezier(.2,1.4,.4,1) forwards; }
        .fade-up { animation: fadeUp 0.4s ease forwards; }
        input::placeholder { color: #5C5A6E; }
        @media (prefers-reduced-motion: reduce) { .stamp, .fade-up { animation: none !important; } }
      `}</style>

      <div style={{ position: "absolute", top: -120, right: -100, width: 320, height: 320, borderRadius: "50%", background: "radial-gradient(circle, rgba(124,92,232,0.25), transparent 70%)", filter: "blur(10px)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: -140, left: -100, width: 320, height: 320, borderRadius: "50%", background: "radial-gradient(circle, rgba(124,92,232,0.12), transparent 70%)", filter: "blur(10px)", pointerEvents: "none" }} />

      {view === "checkin" && <CheckinScreen onAdmin={() => setView(session ? "admin" : "adminLogin")} />}
      {view === "adminLogin" && !session && <AdminLogin onBack={() => setView("checkin")} onOk={() => setView("admin")} />}
      {view === "admin" && session && <AdminPanel onBack={() => setView("checkin")} onLogout={async () => { await supabase.auth.signOut(); setView("checkin"); }} />}
    </div>
  );
}

function CheckinScreen({ onAdmin }) {
  const [nome, setNome] = useState("");
  const [whats, setWhats] = useState("");
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [lastName, setLastName] = useState("");
  const [saveError, setSaveError] = useState("");

  const nomeErr = touched && nome.trim().length < 3;
  const whatsErr = touched && !validWhats(whats);

  const resetForm = () => { setNome(""); setWhats(""); setTouched(false); setSuccess(false); };

  const handleSubmit = async (e) => {
    if (e?.preventDefault) e.preventDefault();
    setTouched(true);
    setSaveError("");
    if (nome.trim().length < 3 || !validWhats(whats)) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("checkin_leads").insert({ nome: nome.trim(), whatsapp: whats });
      if (error) throw error;
      setLastName(nome.trim().split(" ")[0]);
      setSuccess(true);
    } catch (err) {
      console.error("Erro ao salvar check-in:", err);
      setSaveError(`Falha ao salvar: ${err?.message || String(err)}`);
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    if (!success) return;
    const t = setTimeout(resetForm, 3800);
    return () => clearTimeout(t);
  }, [success]);

  return (
    <div style={{ position: "relative", zIndex: 1, minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: "32px 20px", maxWidth: 420, margin: "0 auto" }}>
      <div style={{ textAlign: "center", marginBottom: 28 }}>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 14px", borderRadius: 999, background: "#15151F", border: "1px solid #2A2A3A", marginBottom: 18 }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#34D399", animation: "glow 2s ease-in-out infinite" }} />
          <span style={{ fontSize: 12, color: "#8B889B", letterSpacing: 0.3 }}>check-in ativo</span>
        </div>
        <h1 className="disp" style={{ fontSize: 28, fontWeight: 700, margin: 0, letterSpacing: -0.5 }}>Confirme sua presença</h1>
        <p style={{ fontSize: 14, color: "#8B889B", marginTop: 8, lineHeight: 1.5 }}>Preencha seus dados abaixo pra registrar seu check-in.</p>
      </div>

      {!success ? (
        <div style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 20, padding: 24 }}>
          <label style={{ display: "block", fontSize: 12, color: "#8B889B", marginBottom: 6, fontWeight: 500 }}>Nome completo</label>
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            placeholder="Como te chamam"
            style={{ width: "100%", boxSizing: "border-box", background: "#0F0F18", border: `1px solid ${nomeErr ? "#F87171" : "#2A2A3A"}`, borderRadius: 12, padding: "13px 14px", fontSize: 15, color: "#F2F1F7", outline: "none", marginBottom: nomeErr ? 6 : 18 }}
          />
          {nomeErr && <p style={{ color: "#F87171", fontSize: 12, margin: "0 0 16px" }}>Digite seu nome completo.</p>}

          <label style={{ display: "block", fontSize: 12, color: "#8B889B", marginBottom: 6, fontWeight: 500 }}>WhatsApp</label>
          <input
            value={whats}
            onChange={(e) => setWhats(formatWhats(e.target.value))}
            onKeyDown={(e) => { if (e.key === "Enter") handleSubmit(); }}
            placeholder="(11) 91234-5678"
            inputMode="numeric"
            style={{ width: "100%", boxSizing: "border-box", background: "#0F0F18", border: `1px solid ${whatsErr ? "#F87171" : "#2A2A3A"}`, borderRadius: 12, padding: "13px 14px", fontSize: 15, color: "#F2F1F7", outline: "none", marginBottom: whatsErr ? 6 : 22 }}
          />
          {whatsErr && <p style={{ color: "#F87171", fontSize: 12, margin: "0 0 20px" }}>Informe um número válido com DDD.</p>}

          <button
            type="button"
            onClick={handleSubmit}
            disabled={saving}
            style={{ width: "100%", background: saving ? "#5B47A8" : "#7C5CE8", color: "#fff", border: "none", borderRadius: 12, padding: "14px 0", fontSize: 15, fontWeight: 600, cursor: saving ? "default" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
          >
            {saving ? (<><Loader2 size={17} style={{ animation: "spin 1s linear infinite" }} /> Enviando…</>) : "Fazer check-in"}
          </button>
          {saveError && <p style={{ color: "#F87171", fontSize: 12, margin: "12px 0 0", textAlign: "center" }}>{saveError}</p>}
        </div>
      ) : (
        <div className="fade-up" style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 20, padding: "40px 24px", textAlign: "center" }}>
          <div className="stamp" style={{ width: 76, height: 76, margin: "0 auto 18px", borderRadius: "50%", background: "rgba(52,211,153,0.12)", border: "3px solid #34D399", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Check size={34} color="#34D399" strokeWidth={3} />
          </div>
          <h2 className="disp" style={{ fontSize: 20, fontWeight: 700, margin: "0 0 6px" }}>Check-in confirmado{lastName ? `, ${lastName}` : ""}!</h2>
          <p style={{ fontSize: 13, color: "#8B889B", margin: 0 }}>Obrigado por confirmar. Pode fechar essa tela.</p>
        </div>
      )}

      <button onClick={onAdmin} style={{ marginTop: 30, background: "none", border: "none", color: "#4A4858", fontSize: 12, cursor: "pointer", textAlign: "center" }}>
        Admin
      </button>
    </div>
  );
}

function AdminLogin({ onBack, onOk }) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");
  const [checking, setChecking] = useState(false);

  const submit = async (e) => {
    if (e?.preventDefault) e.preventDefault();
    if (checking) return;
    setChecking(true);
    setErr("");
    const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
    setChecking(false);
    if (error) { setErr(error.message === "Invalid login credentials" ? "E-mail ou senha incorretos." : error.message); return; }
    onOk();
  };

  return (
    <div style={{ position: "relative", zIndex: 1, minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: "32px 20px", maxWidth: 380, margin: "0 auto" }}>
      <button onClick={onBack} style={{ background: "none", border: "none", color: "#8B889B", display: "flex", alignItems: "center", gap: 6, fontSize: 13, cursor: "pointer", marginBottom: 24, padding: 0 }}>
        <ArrowLeft size={15} /> Voltar ao check-in
      </button>
      <div style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 20, padding: 28 }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(124,92,232,0.14)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
          <Lock size={20} color="#A78BFA" />
        </div>
        <h2 className="disp" style={{ fontSize: 19, fontWeight: 700, margin: "0 0 4px" }}>Acesso admin</h2>
        <p style={{ fontSize: 13, color: "#8B889B", margin: "0 0 18px" }}>Entre com o login criado no Supabase (Authentication → Users).</p>
        <div>
          <input
            type="email"
            value={email}
            onChange={(e) => { setEmail(e.target.value); setErr(""); }}
            placeholder="E-mail"
            autoFocus
            style={{ width: "100%", boxSizing: "border-box", background: "#0F0F18", border: `1px solid ${err ? "#F87171" : "#2A2A3A"}`, borderRadius: 12, padding: "12px 14px", fontSize: 14, color: "#F2F1F7", outline: "none", marginBottom: 10 }}
          />
          <input
            type="password"
            value={pass}
            onChange={(e) => { setPass(e.target.value); setErr(""); }}
            onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
            placeholder="Senha"
            style={{ width: "100%", boxSizing: "border-box", background: "#0F0F18", border: `1px solid ${err ? "#F87171" : "#2A2A3A"}`, borderRadius: 12, padding: "12px 14px", fontSize: 14, color: "#F2F1F7", outline: "none", marginBottom: 8 }}
          />
          {err && <p style={{ color: "#F87171", fontSize: 12, margin: "0 0 12px" }}>{err}</p>}
          <button
            type="button"
            onClick={submit}
            disabled={checking}
            style={{ width: "100%", marginTop: 8, background: "#7C5CE8", color: "#fff", border: "none", borderRadius: 12, padding: "12px 0", fontSize: 14, fontWeight: 600, cursor: checking ? "default" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
          >
            {checking ? <Loader2 size={16} style={{ animation: "spin 1s linear infinite" }} /> : "Entrar"}
          </button>
        </div>
      </div>
    </div>
  );
}

function AdminPanel({ onBack, onLogout }) {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [search, setSearch] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [revealed, setRevealed] = useState(() => new Set());
  const [revealAll, setRevealAll] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setLoadError("");
    const { data, error } = await supabase.from("checkin_leads").select("*").order("criado_em", { ascending: false });
    if (error) setLoadError(error.message);
    setLeads(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const toggleReveal = (id) => {
    setRevealed((prev) => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });
  };

  const filtered = leads.filter((l) => {
    if (search && !(`${l.nome} ${l.whatsapp}`.toLowerCase().includes(search.toLowerCase()))) return false;
    const d = l.criado_em.slice(0, 10);
    if (dateFrom && d < dateFrom) return false;
    if (dateTo && d > dateTo) return false;
    return true;
  });

  const exportCsv = (full) => {
    const header = "Nome,WhatsApp,Data/Hora\n";
    const rows = filtered.map((l) => `"${l.nome.replace(/"/g, '""')}","${full ? l.whatsapp : maskWhats(l.whatsapp)}","${fmtDateTime(l.criado_em)}"`).join("\n");
    const blob = new Blob(["\uFEFF" + header + rows], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `checkins_${full ? "completo" : "mascarado"}_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ position: "relative", zIndex: 1, minHeight: "100vh", padding: "24px 18px 40px", maxWidth: 720, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
        <button onClick={onBack} style={{ background: "none", border: "none", color: "#8B889B", display: "flex", alignItems: "center", gap: 6, fontSize: 13, cursor: "pointer", padding: 0 }}>
          <ArrowLeft size={15} /> Check-in
        </button>
        <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: 12, color: "#8B889B" }}>
          <span style={{ display: "flex", alignItems: "center", gap: 6 }}><Users size={14} /> {leads.length}</span>
          <button onClick={onLogout} style={{ background: "none", border: "none", color: "#8B889B", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, padding: 0 }}>
            <LogOut size={13} /> Sair
          </button>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
        <h1 className="disp" style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>Relatório de check-ins</h1>
        <button onClick={() => setRevealAll((v) => !v)} style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 10, padding: "7px 12px", color: revealAll ? "#A78BFA" : "#8B889B", cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 500 }}>
          {revealAll ? <EyeOff size={13} /> : <Eye size={13} />} {revealAll ? "Ocultar números" : "Revelar todos"}
        </button>
      </div>

      {loadError && (
        <div style={{ background: "rgba(248,113,113,0.1)", border: "1px solid #F87171", borderRadius: 10, padding: 12, marginBottom: 14, fontSize: 12, color: "#F87171" }}>
          Erro ao carregar: {loadError}
        </div>
      )}

      <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 16 }}>
        <div style={{ position: "relative", flex: "1 1 180px" }}>
          <Search size={15} color="#5C5A6E" style={{ position: "absolute", left: 12, top: 12 }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar nome ou WhatsApp"
            style={{ width: "100%", boxSizing: "border-box", background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 10, padding: "10px 12px 10px 34px", fontSize: 13, color: "#F2F1F7", outline: "none" }} />
        </div>
        <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 10, padding: "10px 10px", fontSize: 13, color: "#F2F1F7", outline: "none" }} />
        <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 10, padding: "10px 10px", fontSize: 13, color: "#F2F1F7", outline: "none" }} />
        {(search || dateFrom || dateTo) && (
          <button onClick={() => { setSearch(""); setDateFrom(""); setDateTo(""); }} style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 10, padding: "0 12px", color: "#8B889B", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontSize: 12 }}>
            <X size={13} /> Limpar
          </button>
        )}
        <button onClick={() => exportCsv(false)} disabled={!filtered.length} style={{ background: "#7C5CE8", border: "none", borderRadius: 10, padding: "0 14px", color: "#fff", cursor: filtered.length ? "pointer" : "default", opacity: filtered.length ? 1 : 0.5, display: "flex", alignItems: "center", gap: 6, fontSize: 13, fontWeight: 600 }}>
          <Download size={14} /> CSV
        </button>
        {revealAll && (
          <button onClick={() => exportCsv(true)} disabled={!filtered.length} title="Exporta com WhatsApp completo, sem máscara" style={{ background: "#15151F", border: "1px solid #F87171", borderRadius: 10, padding: "0 14px", color: "#F87171", cursor: filtered.length ? "pointer" : "default", opacity: filtered.length ? 1 : 0.5, display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 600 }}>
            <Download size={13} /> CSV completo
          </button>
        )}
      </div>

      <div style={{ background: "#15151F", border: "1px solid #2A2A3A", borderRadius: 16, overflow: "hidden" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", padding: "10px 16px", borderBottom: "1px solid #2A2A3A", fontSize: 11, color: "#5C5A6E", textTransform: "uppercase", letterSpacing: 0.5 }}>
          <span>Nome</span><span>WhatsApp</span><span>Quando</span>
        </div>
        {loading ? (
          <div style={{ padding: 32, textAlign: "center", color: "#5C5A6E", fontSize: 13 }}>Carregando…</div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: 32, textAlign: "center", color: "#5C5A6E", fontSize: 13 }}>Nenhum check-in encontrado.</div>
        ) : (
          filtered.map((l, i) => {
            const isRevealed = revealAll || revealed.has(l.id);
            return (
              <div key={l.id} style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", padding: "12px 16px", borderBottom: i < filtered.length - 1 ? "1px solid #1E1E2A" : "none", fontSize: 13, alignItems: "center" }}>
                <span style={{ fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", paddingRight: 8 }}>{l.nome}</span>
                <span style={{ color: "#8B889B", display: "flex", alignItems: "center", gap: 6 }}>
                  {isRevealed ? l.whatsapp : maskWhats(l.whatsapp)}
                  {!revealAll && (
                    <button onClick={() => toggleReveal(l.id)} style={{ background: "none", border: "none", padding: 0, cursor: "pointer", color: "#5C5A6E", display: "flex" }} title={isRevealed ? "Ocultar" : "Revelar"}>
                      {isRevealed ? <EyeOff size={13} /> : <Eye size={13} />}
                    </button>
                  )}
                </span>
                <span style={{ color: "#5C5A6E", fontSize: 12, whiteSpace: "nowrap" }}>{fmtDateTime(l.criado_em)}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
