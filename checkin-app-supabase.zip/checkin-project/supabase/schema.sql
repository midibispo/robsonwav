-- Tabela de check-ins / captura de leads via QR code
-- Rode isso no SQL Editor do seu projeto Supabase existente.

create table if not exists public.checkin_leads (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  whatsapp text not null,
  criado_em timestamptz not null default now()
);

create index if not exists idx_checkin_leads_criado_em on public.checkin_leads (criado_em desc);

alter table public.checkin_leads enable row level security;

-- Qualquer visitante (anon) pode INSERIR um check-in (é o formulário público via QR).
drop policy if exists "checkin_leads_insert_publico" on public.checkin_leads;
create policy "checkin_leads_insert_publico"
  on public.checkin_leads
  for insert
  to anon, authenticated
  with check (true);

-- Só usuário autenticado (o admin logado via Supabase Auth) pode LER os dados.
drop policy if exists "checkin_leads_select_admin" on public.checkin_leads;
create policy "checkin_leads_select_admin"
  on public.checkin_leads
  for select
  to authenticated
  using (true);

-- Ninguém pode alterar ou apagar via API (proteção extra; faça isso manualmente no painel se precisar).
-- Não criamos policies de update/delete de propósito — por padrão, sem policy = bloqueado.

-- Depois de rodar isso, crie o usuário admin em:
-- Authentication > Users > Add user (email + senha)
-- Esse email/senha é o login usado no painel admin do app.
