# Check-in via QR Code

App de check-in/captura de leads (nome + WhatsApp) com painel admin, usando Supabase como backend.

## 1. Configurar o banco (Supabase que você já tem)

1. Abre o projeto no [supabase.com](https://supabase.com) → **SQL Editor**
2. Cola e roda o conteúdo de `supabase/schema.sql`
3. Vai em **Authentication → Users → Add user** e cria o login do admin (email + senha). É esse login que você vai usar no painel — não tem senha fixa no código.

## 2. Rodar localmente (opcional, pra testar antes de publicar)

```bash
npm install
cp .env.example .env
# edita o .env com a URL e a anon key do seu projeto (Project Settings > API)
npm run dev
```

Abre o link que aparecer (geralmente `http://localhost:5173`).

## 3. Publicar na Vercel (gera link tipo seu-app.vercel.app, sem precisar de domínio)

**Opção A — pelo site (mais simples, sem instalar nada):**
1. Sobe essa pasta num repositório novo no GitHub
2. Entra em [vercel.com](https://vercel.com), "Add New Project", conecta o repositório
3. Em **Environment Variables**, adiciona:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy. Pronto, sem domínio nenhum, a Vercel já gera a URL.

**Opção B — pela linha de comando:**
```bash
npm install -g vercel
vercel login
vercel
# segue os prompts; quando perguntar sobre env vars, adiciona as duas do passo 3
```

## 4. Netlify (alternativa à Vercel, mesmo princípio)

1. [netlify.com](https://netlify.com) → "Add new site" → "Import from Git" (ou arrasta a pasta `dist` depois de rodar `npm run build`, no modo "Deploy manually")
2. Build command: `npm run build` — Publish directory: `dist`
3. Em **Site settings → Environment variables**, adiciona as mesmas duas variáveis

## 5. Gerar o QR code

Depois de publicado, pega a URL gerada (ex: `https://checkin-mbcode.vercel.app`) e gera o QR code apontando pra ela — qualquer gerador de QR online serve, ou eu gero um artifact com o QR se você me mandar a URL final.

## Segurança implementada

- **Insert público, select restrito**: qualquer pessoa pode enviar um check-in (RLS `insert` liberado), mas só o admin autenticado consegue ler a lista (RLS `select` restrito a `authenticated`). Isso é segurança de verdade, no banco — diferente da versão de teste no artifact do Claude, aqui não tem como burlar só olhando o código-fonte do navegador.
- **Login admin via Supabase Auth**: sem senha fixa no código; login e senha reais, gerenciáveis pelo painel do Supabase (dá pra trocar senha, revogar acesso, adicionar outros admins, etc.).
- **Máscara de WhatsApp** no painel, com opção de revelar.
- **Export CSV** com máscara por padrão; versão completa só liberada explicitamente.

## Próximos passos possíveis (não implementados)

- Rate limiting no insert público (hoje qualquer um pode mandar quantos check-ins quiser via API diretamente, não só pela tela)
- Múltiplos eventos (hoje é uma tabela única, sem separação por evento/data específico além do timestamp)
- Domínio próprio (a Vercel permite adicionar depois, se um dia você quiser)
